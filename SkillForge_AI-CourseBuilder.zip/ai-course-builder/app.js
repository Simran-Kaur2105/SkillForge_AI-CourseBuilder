const COURSE_DATA = {
  Python:{title:"Python Programming",level:"Beginner",duration:"4 weeks",lessons:[
    ["Getting started with Python","Install Python, use the interpreter and write your first program."],
    ["Variables and data types","Work with strings, numbers, booleans and type conversion."],
    ["Operators and decisions","Use operators, if, elif and else to control program flow."],
    ["Loops and collections","Practice for/while loops, lists, tuples, sets and dictionaries."],
    ["Functions and modules","Create reusable functions, use parameters and import modules."],
    ["Files, errors and a mini project","Read and write files, handle exceptions and build a small project."]
  ],resources:[
    ["Python official tutorial","https://docs.python.org/3/tutorial/","The official Python tutorial covers syntax, data structures, modules and errors."],
    ["Python documentation","https://docs.python.org/3/","Reference documentation maintained by the Python Software Foundation."],
    ["W3Schools Python","https://www.w3schools.com/python/","Beginner-friendly explanations and browser-based examples."]
  ],video:"Python programming full course for beginners tutorial"},
  C:{title:"C Programming",level:"Beginner",duration:"4 weeks",lessons:[
    ["C fundamentals and setup","Understand source files, compilers, main() and printf()."],
    ["Variables, data types and operators","Use fundamental types, constants, expressions and conversions."],
    ["Conditions and loops","Write decisions with if/switch and repetition with loops."],
    ["Arrays and strings","Store collections of values and work with character arrays."],
    ["Functions and pointers","Understand function calls, addresses and pointer basics."],
    ["Structures and file handling","Organize data with structures and perform basic file operations."]
  ],resources:[
    ["GNU C manual","https://gcc.gnu.org/onlinedocs/","Compiler documentation for the GNU Compiler Collection."],
    ["cppreference: C","https://en.cppreference.com/w/c","A detailed C language reference."],
    ["Learn-C.org","https://www.learn-c.org/","Interactive C lessons and practice."]
  ],video:"C programming full course for beginners"},
  "C++":{title:"C++ Programming",level:"Beginner",duration:"5 weeks",lessons:[
    ["C++ setup and first program","Compile a simple program and understand the structure."],
    ["Types, variables and operators","Learn fundamental types, expressions and conversions."],
    ["Control flow and functions","Use decisions, loops, parameters and return values."],
    ["Arrays, strings and pointers","Work with collections, text and memory addresses."],
    ["Object-oriented programming","Explore classes, objects, constructors and inheritance."],
    ["STL and a mini project","Use vectors, maps and algorithms in a small application."]
  ],resources:[
    ["C++ language reference","https://en.cppreference.com/w/cpp","Reference for C++ language and standard library."],
    ["LearnCpp","https://www.learncpp.com/","Structured C++ lessons with explanations and examples."],
    ["ISO C++ FAQ","https://isocpp.org/faq","Frequently asked questions from the C++ community."]
  ],video:"C++ programming full course for beginners"},
  Java:{title:"Java Programming",level:"Beginner",duration:"5 weeks",lessons:[
    ["Java and the JDK","Understand the JDK, JVM, compilation and first application."],
    ["Variables, types and operators","Use primitive types, expressions and conversions."],
    ["Conditions, loops and arrays","Control execution and store related values."],
    ["Classes and objects","Learn methods, constructors, encapsulation and inheritance."],
    ["Exceptions and collections","Handle errors and work with common collection types."],
    ["Build a small Java application","Combine OOP, collections and input/output."]
  ],resources:[
    ["Dev.java learning","https://dev.java/learn/","Learning material from the Java platform team."],
    ["Java SE documentation","https://docs.oracle.com/en/java/","Official Oracle Java documentation."],
    ["W3Schools Java","https://www.w3schools.com/java/","Beginner-friendly Java tutorials."]
  ],video:"Java programming full course for beginners"},
  JavaScript:{title:"JavaScript Development",level:"Beginner",duration:"4 weeks",lessons:[
    ["JavaScript foundations","Run JavaScript in a browser and understand variables."],
    ["Types, operators and conditions","Work with values, comparisons and branching."],
    ["Loops, arrays and objects","Process collections and structured data."],
    ["Functions and modern JavaScript","Use functions, arrow syntax and modules."],
    ["DOM and events","Make web pages interactive with browser APIs."],
    ["Async JavaScript and project","Understand promises, fetch and build a mini app."]
  ],resources:[
    ["MDN JavaScript Guide","https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide","Comprehensive JavaScript guide maintained by MDN."],
    ["JavaScript.info","https://javascript.info/","In-depth modern JavaScript tutorial."],
    ["MDN Web APIs","https://developer.mozilla.org/en-US/docs/Web/API","Reference for browser APIs and DOM."]
  ],video:"JavaScript full course for beginners"},
  HTML:{title:"HTML & CSS Foundations",level:"Beginner",duration:"3 weeks",lessons:[
    ["HTML document structure","Create semantic pages with headings, links and images."],
    ["Forms and semantic HTML","Build accessible forms and meaningful page structure."],
    ["CSS selectors and box model","Style elements and understand layout fundamentals."],
    ["Flexbox and Grid","Create responsive page layouts."],
    ["Responsive design","Use media queries and mobile-first techniques."],
    ["Build a portfolio page","Combine HTML and CSS in a complete page."]
  ],resources:[
    ["MDN HTML","https://developer.mozilla.org/en-US/docs/Web/HTML","HTML reference and learning guide."],
    ["MDN CSS","https://developer.mozilla.org/en-US/docs/Web/CSS","CSS reference and learning guide."],
    ["web.dev Learn CSS","https://web.dev/learn/css/","Structured CSS learning path."]
  ],video:"HTML CSS full course for beginners"}
};

const QUIZZES = {
 Python:[
  {q:"Which keyword is used to define a function in Python?",o:["function","def","func","define"],a:1,e:"Python uses the def keyword to begin a function definition."},
  {q:"Which data type is immutable?",o:["List","Dictionary","Tuple","Set"],a:2,e:"A tuple cannot be changed after it is created."},
  {q:"What does len([4, 8, 2]) return?",o:["2","3","4","8"],a:1,e:"The list contains three elements, so len() returns 3."},
  {q:"Which loop is commonly used to iterate over a sequence?",o:["repeat","foreach","for","loop"],a:2,e:"A for loop iterates over items in an iterable."},
  {q:"Which symbol starts a comment in Python?",o:["//","#","/*","--"],a:1,e:"A hash symbol begins a single-line Python comment."}
 ],
 C:[
  {q:"Which function is the usual entry point of a C program?",o:["start()","main()","run()","init()"],a:1,e:"Execution of a hosted C program begins in main()."},
  {q:"Which header declares printf()?",o:["stdlib.h","string.h","stdio.h","math.h"],a:2,e:"stdio.h declares standard input/output functions such as printf()."},
  {q:"Which operator accesses a structure member through a pointer?",o:[".","->","&","*"],a:1,e:"The arrow operator accesses a member through a structure pointer."},
  {q:"Array indexing in C starts at:",o:["0","1","-1","Depends on compiler"],a:0,e:"The first element of a C array has index zero."},
  {q:"Which keyword declares a read-only object?",o:["fixed","static","const","readonly"],a:2,e:"const qualifies an object whose value cannot be modified through that lvalue."}
 ],
 "C++":[
  {q:"Which feature bundles data and methods in a class?",o:["Encapsulation","Compilation","Iteration","Casting"],a:0,e:"Encapsulation groups data and operations while controlling access."},
  {q:"Which operator is used for scope resolution?",o:["->","::",".","=>"],a:1,e:"The :: operator qualifies names in a namespace or class scope."},
  {q:"Which container is a dynamic array in the STL?",o:["map","vector","set","stack"],a:1,e:"std::vector is a sequence container that can grow dynamically."},
  {q:"A constructor has:",o:["A return type","The class name","The name init","A bool return"],a:1,e:"A constructor has the same name as its class and no return type."},
  {q:"Which header provides std::cout?",o:["<stdio.h>","<iostream>","<string>","<fstream>"],a:1,e:"The iostream header provides standard stream objects such as std::cout."}
 ],
 Java:[
  {q:"Which component executes Java bytecode?",o:["JVM","JDK only","Javadoc"," javac editor"],a:0,e:"The Java Virtual Machine executes compiled Java bytecode."},
  {q:"Which keyword creates an object?",o:["make","new","class","this"],a:1,e:"The new operator creates an object instance."},
  {q:"Which concept allows a class to inherit another class?",o:["Encapsulation","Inheritance","Overloading","Casting"],a:1,e:"Inheritance lets a class derive fields and methods from another class."},
  {q:"Which method is the common Java application entry point?",o:["start()","run()","public static void main","init()"],a:2,e:"A standard Java application entry point is public static void main(String[] args)."},
  {q:"Which collection does not allow duplicate elements?",o:["List","Set","ArrayList","Queue"],a:1,e:"The Set interface models a collection with no duplicate elements."}
 ],
 JavaScript:[
  {q:"Which keyword declares a block-scoped variable that can be reassigned?",o:["var","let","const","static"],a:1,e:"let declares a block-scoped variable that can be reassigned."},
  {q:"Which method selects an element by CSS selector?",o:["getElement()","querySelector()","selectCSS()","findNode()"],a:1,e:"document.querySelector() returns the first matching element."},
  {q:"What does === check?",o:["Assignment","Loose equality","Strict equality","Type only"],a:2,e:"Strict equality compares without type coercion."},
  {q:"Which value represents an intentional absence of object value?",o:["undefined","null","NaN","false"],a:1,e:"null is commonly used to represent an intentional absence of value."},
  {q:"Which syntax creates an arrow function?",o:["function =>","() => {}","-> {}","func() {}"],a:1,e:"Arrow functions use the => syntax."}
 ],
 HTML:[
  {q:"Which element is the top-level HTML element?",o:["<body>","<head>","<html>","<main>"],a:2,e:"The html element is the root element of an HTML document."},
  {q:"Which CSS property changes text color?",o:["font-style","color","background","text-size"],a:1,e:"The color property sets the foreground color of text."},
  {q:"Which layout system is designed for one-dimensional layouts?",o:["Flexbox","Grid","Float","Position"],a:0,e:"Flexbox is primarily a one-dimensional layout system."},
  {q:"Which attribute provides alternative text for an image?",o:["title","src","alt","href"],a:2,e:"The alt attribute provides a text alternative for an image."},
  {q:"Which CSS unit is relative to the root font size?",o:["px","rem","vh","%"],a:1,e:"rem is relative to the root element's font size."}
 ]
};

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
let state = loadState();
let currentCourse = null, activeQuiz = null, quizIndex = 0, answers = [], timerId = null, secondsLeft = 300;

function loadState(){try{return JSON.parse(localStorage.getItem("skillforgeState"))||{courses:{},scores:[],lessons:0,points:0,streak:0}}catch{return {courses:{},scores:[],lessons:0,points:0,streak:0}}}
function saveState(){localStorage.setItem("skillforgeState",JSON.stringify(state));renderStats()}
function notify(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2400)}
function courseKey(name){const found=Object.keys(COURSE_DATA).find(k=>k.toLowerCase()===name.toLowerCase());return found||name}
function getCourse(name){const key=courseKey(name);if(COURSE_DATA[key])return {...COURSE_DATA[key],key};return makeCustomCourse(name)}
function makeCustomCourse(name){const safe=name.trim()||"Programming";return {key:safe,title:safe+" Course",level:"Custom",duration:"Self-paced",lessons:[["Foundations and setup","Understand the purpose, setup and core terminology."],["Core syntax and concepts","Learn the fundamental building blocks and common patterns."],["Control flow and problem solving","Practice decisions, repetition and breaking problems into steps."],["Data structures and reusable code","Organize information and write reusable components."],["Applied practice","Solve small exercises and review common mistakes."],["Build a guided mini project","Combine concepts in a practical beginner project."]],resources:[["Official documentation","https://www.google.com/search?q="+encodeURIComponent(safe+" official documentation"),"Search for the official documentation and primary learning resources."],["Beginner tutorial","https://www.google.com/search?q="+encodeURIComponent(safe+" beginner tutorial site:edu OR site:org"),"Find university and established educational tutorials."],["Reference materials","https://www.google.com/search?q="+encodeURIComponent(safe+" language reference"),"Look for language specifications and reference material."]],video:safe+" programming tutorial for beginners"}}
function ensureCourse(name){const c=getCourse(name);if(!state.courses[c.key])state.courses[c.key]={completed:[],created:Date.now(),title:c.title};saveState();return c}
function showView(view){$$(".view").forEach(v=>v.classList.remove("active"));const target=$("#"+view+"View");if(target)target.classList.add("active");$$(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.view===view));$("#breadcrumbCurrent").textContent=view==="course"?"Course details":view==="my-learning"?"My learning":view==="quiz"?"Quiz arena":view==="catalog"?"Explore courses":view==="leaderboard"?"Leaderboard":"Overview";if(view==="catalog")renderCatalog();if(view==="my-learning")renderMyLearning();if(view==="quiz")renderQuizHome();if(view==="leaderboard")renderLeaderboard();$("#sidebar").classList.remove("open");window.scrollTo({top:0,behavior:"smooth"})}
function courseCard(key){const c=getCourse(key),p=state.courses[c.key],done=p?.completed?.length||0,percent=Math.round(done/c.lessons.length*100);return `<article class="course-card"><div class="course-top"><div class="language-icon">${c.key.slice(0,2).toUpperCase()}</div><span class="level-tag">${c.level}</span></div><h3>${escapeHtml(c.title)}</h3><p>A guided path with core concepts, practical learning and knowledge checks.</p><div class="course-meta"><span>▤ ${c.lessons.length} modules</span><span>◷ ${c.duration}</span></div><div class="card-bottom"><div class="progress-track"><div class="progress-fill" style="width:${percent}%"></div></div><button class="open-course" data-open-course="${escapeAttr(c.key)}">${p?"Continue":"Explore"} →</button></div></article>`}
function renderFeatured(){$("#featuredCourses").innerHTML=["Python","C++","Java","JavaScript","C","HTML"].map(courseCard).join("");}
function renderCatalog(filter="") {const keys=["Python","C","C++","Java","JavaScript","HTML"];const matches=keys.filter(k=>(getCourse(k).title+" "+k).toLowerCase().includes(filter.toLowerCase()));$("#catalogCourses").innerHTML=matches.map(courseCard).join("")||'<div class="empty-state">No matching course found. Try another keyword.</div>';$("#catalogCount").textContent=matches.length+" courses"}
function renderStats(){$("#statCourses").textContent=Object.keys(state.courses).length;$("#statLessons").textContent=state.lessons;$("#statMinutes").textContent=state.points;$("#streakCount").textContent=state.streak||0}
function openCourse(name){const c=ensureCourse(name);currentCourse=c;const progress=state.courses[c.key];$("#courseDetail").innerHTML=`<div class="course-hero"><span class="ai-pill">✦ PERSONAL LEARNING PATH</span><h1>${escapeHtml(c.title)}</h1><p>${escapeHtml(c.level)} · ${c.duration} · ${c.lessons.length} modules. Follow the modules in order, explore trusted references and test your understanding.</p><button class="primary-button" id="startCourseQuiz">Take a course quiz →</button></div><div class="course-layout"><div class="content-panel"><div class="section-heading"><div><div class="eyebrow">LEARNING ROADMAP</div><h2>Course modules</h2></div><span class="small-muted">${progress.completed.length}/${c.lessons.length} complete</span></div>${c.lessons.map((l,i)=>`<div class="lesson-row"><div class="lesson-check">${progress.completed.includes(i)?"✓":String(i+1).padStart(2,"0")}</div><div class="lesson-info"><strong>${escapeHtml(l[0])}</strong><small>${escapeHtml(l[1])}</small></div><button data-lesson="${i}">${progress.completed.includes(i)?"Review":"Study lesson"}</button></div>`).join("")}</div><aside class="resource-panel"><h3>Trusted learning resources</h3><p class="resource-note">Start with primary documentation, then use additional tutorials to reinforce concepts.</p>${c.resources.map(r=>`<div class="resource-item"><a href="${escapeAttr(r[1])}" target="_blank" rel="noopener">${escapeHtml(r[0])} ↗</a><p>${escapeHtml(r[2])}</p></div>`).join("")}<h3 style="margin-top:20px">Video learning</h3><p class="resource-note">YouTube search results for this course. Review the instructor, upload date and content before relying on a video.</p><a class="open-course" target="_blank" rel="noopener" href="https://www.youtube.com/results?search_query=${encodeURIComponent(c.video)}">Find tutorials on YouTube ↗</a></aside></div>`;showView("course")}
function showLesson(index){const c=currentCourse;if(!c)return;const lesson=c.lessons[index];const progress=state.courses[c.key];const done=progress.completed.includes(index);const detail=$("#courseDetail");const old=detail.querySelector(".lesson-reading");if(old)old.remove();const panel=document.createElement("div");panel.className="content-panel lesson-reading";panel.style.marginTop="16px";panel.innerHTML=`<div class="eyebrow">MODULE ${index+1}</div><h2>${escapeHtml(lesson[0])}</h2><p class="lesson-body">${escapeHtml(lesson[1])}</p><p class="lesson-body">Learning suggestion: read the linked official documentation, write a small example in your own editor, change the example and explain what happens. Make sure you can describe the idea without copying the code.</p><button class="primary-button" id="completeLesson">${done?"Completed ✓":"Mark lesson complete"}</button>`;detail.appendChild(panel);panel.scrollIntoView({behavior:"smooth",block:"center"});$("#completeLesson").onclick=()=>{if(!done){progress.completed.push(index);state.lessons++;saveState();notify("Lesson marked complete!");openCourse(c.key)}else notify("This lesson is already complete.")}}
function renderMyLearning(){const entries=Object.keys(state.courses);$("#myLearningList").innerHTML=entries.length?`<div class="course-grid">${entries.map(courseCard).join("")}</div>`:'<div class="empty-state"><strong>Your learning journey starts here.</strong>Choose a course and your progress will appear here.<br><br><button class="primary-button" data-view="catalog">Explore courses</button></div>'}
function renderQuizHome(){const entries=Object.keys(COURSE_DATA);$("#quizArea").innerHTML=`<div class="course-grid">${entries.map(k=>`<article class="course-card"><div class="course-top"><div class="language-icon">${k.slice(0,2).toUpperCase()}</div><span class="level-tag">5 questions · 5 min</span></div><h3>${escapeHtml(k)} knowledge check</h3><p>Test your understanding with a short topic-based quiz and review explanations.</p><button class="primary-button" data-quiz="${escapeAttr(k)}">Start quiz →</button></article>`).join("")}</div><div style="margin-top:22px"><div class="section-heading"><div><div class="eyebrow">RECENT RESULTS</div><h2>Your quiz attempts</h2></div></div>${state.scores.length?scoreRows(): '<div class="empty-state">No attempts yet. Complete a quiz to see your results.</div>'}</div>`}
function scoreRows(){return `<div class="leaderboard-card">${[...state.scores].reverse().slice(0,8).map((s,i)=>`<div class="leader-row"><span class="rank">#${i+1}</span><span class="leader-name">${escapeHtml(s.course)} quiz</span><span class="leader-score">${s.score}/${s.total}</span><span class="leader-date">${new Date(s.date).toLocaleDateString()}</span></div>`).join("")}</div>`}
function startQuiz(course){activeQuiz=course;quizIndex=0;answers=Array(QUIZZES[course].length).fill(null);secondsLeft=300;renderQuestion();showView("quiz");}
function renderQuestion(){clearInterval(timerId);const questions=QUIZZES[activeQuiz];const q=questions[quizIndex];$("#quizArea").innerHTML=`<div class="quiz-start"><div class="quiz-topline"><span>${escapeHtml(activeQuiz)} · Question ${quizIndex+1} of ${questions.length}</span><span class="timer" id="quizTimer">05:00</span></div><div class="progress-track"><div class="progress-fill" style="width:${(quizIndex+1)/questions.length*100}%"></div></div><p class="quiz-question" style="margin-top:22px">${escapeHtml(q.q)}</p><div class="quiz-options">${q.o.map((o,i)=>`<button class="quiz-option ${answers[quizIndex]===i?"selected":""}" data-answer="${i}"><b>${String.fromCharCode(65+i)}.</b> &nbsp;${escapeHtml(o)}</button>`).join("")}</div><div class="quiz-actions"><button class="subtle-button" id="quitQuiz">Exit quiz</button><button class="primary-button" id="nextQuestion">${quizIndex===questions.length-1?"Submit quiz":"Next question →"}</button></div></div>`;$$("[data-answer]").forEach(b=>b.onclick=()=>{answers[quizIndex]=Number(b.dataset.answer);renderQuestion()});$("#nextQuestion").onclick=()=>{if(answers[quizIndex]===null){notify("Choose an answer first.");return}if(quizIndex<questions.length-1){quizIndex++;renderQuestion()}else finishQuiz()};$("#quitQuiz").onclick=()=>{clearInterval(timerId);renderQuizHome()};timerId=setInterval(()=>{secondsLeft--;const el=$("#quizTimer");if(el)el.textContent=`${String(Math.floor(secondsLeft/60)).padStart(2,"0")}:${String(secondsLeft%60).padStart(2,"0")}`;if(secondsLeft<=0){clearInterval(timerId);finishQuiz()}},1000)}
function finishQuiz(){clearInterval(timerId);const qs=QUIZZES[activeQuiz];let score=0;qs.forEach((q,i)=>{if(answers[i]===q.a)score++});state.scores.push({course:activeQuiz,score,total:qs.length,date:Date.now()});state.points+=score*10;state.streak=Math.max(1,state.streak||0);saveState();$("#quizArea").innerHTML=`<div class="quiz-start"><div class="eyebrow">QUIZ COMPLETED</div><h2>Nice work. Here's your result.</h2><div class="score-circle">${score}/${qs.length}</div><p class="muted">You earned ${score*10} points. ${score===qs.length?"Perfect score — excellent work!":score>=3?"Good progress. Review the explanations below to strengthen your understanding.":"Keep practising. Review the explanations and try again."}</p>${qs.map((q,i)=>`<div class="lesson-row"><div class="lesson-check">${answers[i]===q.a?"✓":"×"}</div><div class="lesson-info"><strong>${i+1}. ${escapeHtml(q.q)}</strong><small>Your answer: ${answers[i]===null?"Not answered":escapeHtml(q.o[answers[i]])} · Correct: ${escapeHtml(q.o[q.a])}<br>${escapeHtml(q.e)}</small></div></div>`).join("")}<button class="primary-button" id="retryQuiz" style="margin-top:18px">Try again →</button></div>`;$("#retryQuiz").onclick=()=>startQuiz(activeQuiz)}
function renderLeaderboard(){const scores=[...state.scores].sort((a,b)=>b.score/b.total-a.score/a.total||b.date-a.date);$("#leaderboardContent").innerHTML=scores.length?`<div class="leader-row" style="color:var(--muted);font-size:10px;font-weight:700"><span>RANK</span><span>COURSE</span><span>SCORE</span><span>DATE</span></div>${scores.map((s,i)=>`<div class="leader-row"><span class="rank">${["🥇","🥈","🥉"][i]||"#"+(i+1)}</span><span class="leader-name">${escapeHtml(s.course)} quiz</span><span class="leader-score">${s.score}/${s.total}</span><span class="leader-date">${new Date(s.date).toLocaleDateString()}</span></div>`).join("")}`:'<div class="empty-state"><strong>Your leaderboard is waiting.</strong>Take a quiz to record your first score.</div>'}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function escapeAttr(s){return escapeHtml(s)}
function buildCourse(query){const topic=String(query||"").trim();if(!topic)return;notify("Preparing your learning path...");const cleaned=topic.replace(/\s+(for|course|programming|beginner|beginners).*/i,"").trim()||topic;openCourse(cleaned)}
$$("[data-view]").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
$("#courseSearchForm").addEventListener("submit",e=>{e.preventDefault();buildCourse($("#courseInput").value)});
$$("[data-course]").forEach(b=>b.addEventListener("click",()=>buildCourse(b.dataset.course)));
$("#featuredCourses").addEventListener("click",e=>{const b=e.target.closest("[data-open-course]");if(b)openCourse(b.dataset.openCourse)});
$("#catalogCourses").addEventListener("click",e=>{const b=e.target.closest("[data-open-course]");if(b)openCourse(b.dataset.openCourse)});
$("#courseDetail").addEventListener("click",e=>{const lesson=e.target.closest("[data-lesson]");if(lesson)showLesson(Number(lesson.dataset.lesson));if(e.target.id==="startCourseQuiz"){const key=currentCourse.key in QUIZZES?currentCourse.key:null;if(key)startQuiz(key);else notify("A built-in quiz is not available for this custom course yet.")}});
$("#myLearningList").addEventListener("click",e=>{const b=e.target.closest("[data-open-course]");if(b)openCourse(b.dataset.openCourse)});
$("#quizArea").addEventListener("click",e=>{const b=e.target.closest("[data-quiz]");if(b)startQuiz(b.dataset.quiz)});
$("#catalogFilter").addEventListener("input",e=>renderCatalog(e.target.value));
$("#themeToggle").onclick=()=>{document.body.classList.toggle("dark");localStorage.setItem("skillforgeTheme",document.body.classList.contains("dark")?"dark":"light")};
$("#mobileMenu").onclick=()=>$("#sidebar").classList.toggle("open");
if(localStorage.getItem("skillforgeTheme")==="dark")document.body.classList.add("dark");
renderFeatured();renderStats();
