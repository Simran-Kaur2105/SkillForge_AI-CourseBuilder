# SkillForge AI — Frontend-only Course Builder

A responsive programming-learning website built with **HTML, CSS and JavaScript only**. This version keeps the original SkillForge design and frontend learning features while removing the Node.js/Express backend and server-side API configuration.

## Features

- Course library for Python, C, C++, Java, JavaScript and HTML/CSS.
- Topic-based course roadmaps generated from built-in JavaScript templates.
- Lesson roadmap and browser-saved completion progress.
- Curated links to official documentation and established learning resources.
- YouTube search links for finding tutorials.
- Timed multiple-choice quizzes, scoring and answer explanations.
- Personal leaderboard and quiz history stored in the current browser.
- Responsive layout, mobile navigation and light/dark theme.

## Technologies used

- **HTML** — page structure and content.
- **CSS** — visual design, layout, themes and responsive behaviour.
- **JavaScript** — course templates, navigation, quizzes, timers, scoring and browser storage.
- **localStorage** — saves progress, theme preference and quiz results in the browser.

## Run the project

You do not need Node.js, npm, Express, a `.env` file or API keys for this version.

1. Extract the project folder.
2. Open the `ai-course-builder` folder in Visual Studio Code.
3. Install the **Live Server** extension if it is not already installed.
4. Right-click `index.html`.
5. Select **Open with Live Server**.
6. Your browser should open the website, usually at an address beginning with `http://127.0.0.1:5500/`.

You can also open `index.html` directly in a browser, although Live Server is more convenient while editing.

## How custom course generation works in this version

The course search uses JavaScript templates in `app.js`. It does not call an AI model. Known topics open their predefined course outlines. Other topics receive a general six-module starter roadmap, with links that search for relevant documentation and tutorials.

The project name and visual branding remain **SkillForge AI**, but this frontend-only edition does not make live AI API calls. To add real AI-generated course content safely in a future version, connect the frontend to a secure backend or serverless function that stores the provider API key outside browser code. Never put a private API key in `app.js` or other public frontend files.

## Storage and leaderboard limitations

Progress, quiz scores and theme preference are stored in the browser using `localStorage`. They are not shared between students, browsers or devices. Clearing browser site data may remove this saved information. A shared multi-user leaderboard requires a backend and database.

## Trusted starter resources included

- Python: https://docs.python.org/3/
- C: https://en.cppreference.com/w/c and https://gcc.gnu.org/onlinedocs/
- C++: https://en.cppreference.com/w/cpp and https://www.learncpp.com/
- Java: https://dev.java/learn/ and https://docs.oracle.com/en/java/
- JavaScript: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide
- HTML/CSS: https://developer.mozilla.org/en-US/docs/Web/HTML and https://developer.mozilla.org/en-US/docs/Web/CSS

## Project files

- `index.html` — website structure.
- `styles.css` — styling and responsive layout.
- `app.js` — all frontend behaviour and built-in course/quiz data.
- `README.md` — setup and project documentation.
